def rep(s,a,b):
    assert s.count(a)==1,a[:70];return s.replace(a,b)
def ed(f,fn):
    s=open(f,encoding='utf-8').read();s=fn(s);open(f,'w',encoding='utf-8').write(s)
def idx(s):
    blk=r'''var slug=n=>n.toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
var dia=()=>new Date().toLocaleDateString('sv-SE').replace(/-/g,'');
function hit(k){try{if(!D||!D.config.cid||/preview/.test(location.search)||localStorage.getItem('dd_nt'))return;fetch('https://api.counterapi.dev/v1/'+D.config.cid+'/'+k+'/up',{mode:'no-cors',keepalive:true}).catch(()=>{})}catch(e){}}
function zap(){hit('zap');hit('dz-'+dia())}
function track(){try{if(sessionStorage.getItem('dd_s'))return;sessionStorage.setItem('dd_s','1');hit('visitas');hit('dv-'+dia());if(!localStorage.getItem('dd_u')){localStorage.setItem('dd_u','1');hit('visitantes')}}catch(e){}}
document.addEventListener('click',e=>{if(e.target.closest('[data-wa]'))zap()});
'''
    s=rep(s,"function pick(",blk+"function pick(")
    s=rep(s,"function order(p){\n  var v=pr(p),","function order(p){\n  hit('interesse');hit('i-'+slug(p.n));\n  var v=pr(p),")
    s=rep(s,r"window.open(wa(L.filter(x=>x!==null).join('\n')),'_blank');m.close()}};",r"zap();hit('pedidos');window.open(wa(L.filter(x=>x!==null).join('\n')),'_blank');m.close()}};")
    s=rep(s,"if(b.q){e.preventDefault();window.open(wa(b.q),'_blank')}","if(b.q){e.preventDefault();zap();window.open(wa(b.q),'_blank')}")
    s=rep(s,"head();banners();render()})","head();banners();render();track()})")
    return s
ed('site/index.html',idx)
def adm(s):
    s=rep(s,'<button data-t="loja">','<button data-t="stats">📊 Estatísticas</button><button data-t="loja">')
    s=rep(s,".tabs button{flex:1;padding:12px;",".tabs button{flex:1;padding:12px 4px;font-size:13px;")
    s=rep(s,"Descartar rascunho e voltar ao publicado</button></div>","Descartar rascunho e voltar ao publicado</button></div>\n  <div id=\"stats\" hidden><div class=\"bar\"><button class=\"b\" id=\"rs\">↻ Atualizar</button><span>Contagem anônima. Os seus acessos como administrador não são contados.</span></div><div id=\"sx\"></div></div>")
    s=rep(s,"try{sessionStorage.setItem('dd_ok','1')}catch(e){}$('login')","try{sessionStorage.setItem('dd_ok','1');localStorage.setItem('dd_nt','1')}catch(e){}$('login')")
    s=rep(s,"D=d;draw()","D=d;if(!D.config.cid){D.config.cid='ddias-'+Math.random().toString(36).slice(2,10);save()}draw()")
    s=rep(s,"['produtos','banners','loja'].forEach(x=>$(x).hidden=x!==t)};","['produtos','banners','loja','stats'].forEach(x=>$(x).hidden=x!==t);if(t==='stats')stats()};")
    js=r'''const API='https://api.counterapi.dev/v1/',slug=n=>n.toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
const cnt=async k=>{try{const r=await fetch(API+D.config.cid+'/'+k+'/');if(r.status===404)return 0;if(!r.ok)return null;const j=await r.json();return +(j.count??j.value??0)}catch(e){return null}};
async function stats(){
  const el=$('sx');el.innerHTML='<p style="padding:20px;color:var(--mut)">Carregando…</p>';
  const ds=[...Array(7)].map((_,i)=>{const d=new Date();d.setDate(d.getDate()-i);return d}),dk=d=>d.toLocaleDateString('sv-SE').replace(/-/g,'');
  const all=await Promise.all([Promise.all(['visitantes','visitas','zap','pedidos','interesse'].map(cnt)),Promise.all(ds.map(d=>cnt('dv-'+dk(d)))),Promise.all(ds.map(d=>cnt('dz-'+dk(d)))),Promise.all(D.produtos.map(p=>cnt('i-'+slug(p.n))))]);
  const [T,V,Z,I]=all;
  if(all.flat().every(x=>x===null))return el.innerHTML='<div class="tip">Não foi possível ler as estatísticas agora (serviço de contagem indisponível ou bloqueado pelo navegador). Tente novamente em instantes.</div>';
  const n=x=>x===null?'—':x.toLocaleString('pt-BR'),mx=Math.max(1,...V.map(x=>x||0),...Z.map(x=>x||0));
  const card=(t,v,s)=>`<div class="it" style="grid-template-columns:1fr;text-align:center"><div style="font-size:12px;color:var(--mut);font-weight:700">${t}</div><div style="font-size:30px;font-weight:800">${v}</div><div style="font-size:11px;color:var(--mut)">${s}</div></div>`;
  const tx=T[1]?Math.round((T[2]||0)/T[1]*100):0;
  el.innerHTML=`<div class="f" style="margin-bottom:6px">${card('👥 Pessoas que entraram',n(T[0]),'visitantes únicos (por aparelho)')}${card('🌐 Acessos',n(T[1]),'visitas ao site')}${card('💬 Cliques no WhatsApp',n(T[2]),tx+'% dos acessos')}${card('📦 Pedidos enviados',n(T[3]),'pelo formulário "Tenho interesse"')}</div>
  <div class="bar" style="display:block"><b>Últimos 7 dias</b> <small style="color:var(--mut)">(azul = acessos, laranja = cliques no WhatsApp)</small>${ds.map((d,i)=>`<div style="display:grid;grid-template-columns:78px 1fr;gap:8px;align-items:center;margin-top:8px"><span>${d.toLocaleDateString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit'})}</span><div><div style="background:#6366f1;height:8px;border-radius:4px;width:${(V[i]||0)/mx*100}%;min-width:2px"></div><div style="background:var(--o);height:8px;border-radius:4px;margin-top:3px;width:${(Z[i]||0)/mx*100}%;min-width:2px"></div><small style="color:var(--mut)">${n(V[i])} acessos · ${n(Z[i])} cliques</small></div></div>`).join('')}</div>
  <div class="bar" style="display:block"><b>Produtos mais clicados ("Tenho interesse")</b>${D.produtos.map((p,i)=>[p.n,I[i]||0]).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>`<div style="display:flex;justify-content:space-between;margin-top:8px"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')||'<p style="margin-top:8px;color:var(--mut)">Ainda sem cliques.</p>'}</div>`}
$('rs').onclick=stats;
'''
    return rep(s,"$('tabs').onclick=",js+"$('tabs').onclick=")
ed('site/admin.html',adm)
def gen(s):
    return rep(s,"D=dict(config=dict(nome=","try:cid=json.load(open('site/dados.json',encoding='utf-8'))['config']['cid']\nexcept Exception:cid='ddias-'+__import__('secrets').token_hex(4)\nD=dict(config=dict(cid=cid,nome=")
ed('gen.py',gen)
