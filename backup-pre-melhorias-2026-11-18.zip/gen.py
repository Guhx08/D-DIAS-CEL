import json,base64,os
LOGO='https://daqjvsyrnfzyttyrzlvq.supabase.co/storage/v1/object/public/istore-images-new/ac263e38-0382-4f72-baa7-ce3be636e6e1/logos/16ba01801b962e009f5ba27e4058f8bc08792455958d4c3ca1ccd06c375307ea.jpeg'
B,G,K,R,W,Gd,Or,Sg,Gr='#b8aea4|Bege','#4a90e2|Azul','#1c1c1e|Preto','#7a2a35|Vinho','#eeeeee|Branco','#e6cf9f|Dourado','#e0752f|Laranja','#a8c5ae|Verde','#8a8a8a|Cinza'
def P(n,e,c,p,img,cores):return dict(n=n,e=e,c=c,p=p,promo=0,img='imagens/'+img+'.jpg',cores=cores,on=True)
prod=[P('iPhone 18 Pro Max','256GB · 4 cores','Lacrado',9050,'iphone-18-pro-max',[B,G,K,R]),
P('iPhone 17 Pro Max','256GB · 1 cor','Semi',7590,'iphone-17-pro-max',[B]),
P('iPhone 17 Pro','256GB · 1 cor','Semi',6500,'iphone-17-pro',[Or]),
P('iPhone 17','256GB · 1 cor','Semi',5000,'iphone-17',[Sg]),
P('iPhone 16 Pro Max','256GB · 2 cores','Semi',5150,'iphone-16-pro-max',[B,W]),
P('iPhone 16 Pro','2 cores','Semi',4400,'iphone-16-pro',[Gd,B]),
P('iPhone 15 Pro Max','256GB · 3 cores','Semi',4280,'iphone-15-pro-max',[W,G,B]),
P('iPhone 15 Pro','1 cor','Semi',3650,'iphone-15-pro',[G]),
P('iPhone 15 Plus','1 cor','Semi',3050,'iphone-15-plus',[G]),
P('iPhone 15','1 cor','Semi',2950,'iphone-15',[K]),
P('iPhone 14 Pro Max','2 cores','Semi',3450,'iphone-14-pro-max',[K,W]),
P('iPhone 14 Pro','256GB · 1 cor','Semi',3150,'iphone-14-pro',[Gd]),
P('iPhone 14','1 cor','Semi',2230,'iphone-14',[Gr]),
P('iPhone 13','2 cores','Semi · Grade A+',1800,'iphone-13',[K,G]),
P('iPhone 12','1 cor','Semi · Grade A+',1790,'iphone-12',[K]),
P('iPhone Duo','512GB · 2 cores','Lacrado',15500,'iphone-duo',['#f0f0f0|Branco',K]),
P('Carregador USB-C – 20W','1 cor','Lacrado',185.99,'carregador-usb-c-20w',['#cccccc|Branco'])]
ban=[dict(on=True,t='iPhone 18 Pro Max chegou!',s='Lacrado, com garantia e entrega rápida. A partir de R$ 9.050,00.',b='Quero o meu',q='Olá! Tenho interesse no iPhone 18 Pro Max lacrado.',bg='#FF6B00,#ff9a3c',img=''),
dict(on=True,t='Seminovos revisados com garantia',s='Procedência, teste completo e parcelamento no cartão.',b='Ver seminovos',q='',bg='#16181d,#3a3f4a',img=''),
dict(on=True,t='Entrega rápida em Osasco e região',s='Chame no WhatsApp e receba no mesmo dia.',b='Falar agora',q='Olá! Gostaria de saber sobre entrega.',bg='#0f766e,#14b8a6',img='')]
try:cid=json.load(open('site/dados.json',encoding='utf-8'))['config']['cid']
except Exception:cid='ddias-'+__import__('secrets').token_hex(4)
D=dict(config=dict(sb=dict(url='https://tnmggsriokdmksztgoch.supabase.co',key='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRubWdnc3Jpb2tkbWtzenRnb2NoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ4NzAzNzYsImV4cCI6MjExMDQ0NjM3Nn0.C5cEHQfOSEN_Cg76-7oX1VvTgmnH9objgYwqWnumJt0'),nome='D’DIAS CEL',cidade='Osasco - SP',wa='5511964013198',ig='d.diascel',logo=LOGO),banners=ban,produtos=prod)
json.dump(D,open('site/dados.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
# preview: embed data + images
for p in prod:
    p['img']='data:image/jpeg;base64,'+base64.b64encode(open('site/'+p['img'],'rb').read()).decode()
inj='<script>window.__DADOS='+json.dumps(D,ensure_ascii=False)+';</script>\n<script>'
for f in ['index','admin']:
    s=open(f'site/{f}.html',encoding='utf-8').read()
    if f=='index':s=s.replace('href="admin.html" id="adm"','href="https://claude.ai/artifact/K42tbx5HUCYoFkojpbWpBm" target="_blank" id="adm"')
    i=s.rindex('<script>');s=s[:i]+inj+s[i+8:]
    open(f'/mnt/user-data/outputs/preview-{f}.html','w',encoding='utf-8').write(s)
