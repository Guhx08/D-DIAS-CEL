import re
# ---- admin: junta o estilo do painel escuro com o novo template ----
st=open('admin_new.html',encoding='utf-8').read()
style=st[st.index('<style>')+7:st.index('</style>')]
open('site/admin.html','w',encoding='utf-8').write(open('admin_sb.tpl',encoding='utf-8').read().replace('{{STYLE}}',style))
# ---- index ----
s=open('site/index.html',encoding='utf-8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:70];s=s.replace(a,b)
def cut(a,b,new):
    global s
    i=s.index(a);j=s.index(b,i)+len(b);s=s[:i]+new+s[j:]
# carregar dados (Supabase com fallback para dados.json)
cut("function load(){","function head(){","""async function load(){
  var base=window.__DADOS||await fetch('dados.json?'+Date.now()).then(r=>r.json()),sb=base.config.sb;
  if(sb&&sb.key&&sb.url&&!/COLE/.test(sb.key)){
    try{
      var H={apikey:sb.key,Authorization:'Bearer '+sb.key},g=p=>fetch(sb.url+'/rest/v1/'+p,{headers:H}).then(r=>{if(!r.ok)throw 0;return r.json()});
      var a=await Promise.all([g('produtos?select=*&ativo=eq.true&order=ordem.asc'),g('banners?select=*&ativo=eq.true&order=ordem.asc'),g('config?select=*&id=eq.1')]),c=a[2][0]||{};
      return{_sb:1,config:{nome:c.nome||base.config.nome,cidade:c.cidade||base.config.cidade,wa:c.wa||base.config.wa,ig:c.ig||base.config.ig,logo:c.logo||base.config.logo,sb:sb},
        banners:a[1].map(b=>({on:true,t:b.titulo,s:b.subtitulo,b:b.botao,q:b.mensagem,bg:b.cor,img:b.img})),
        produtos:a[0].map(p=>({id:p.id,n:p.nome,e:p.detalhes,c:p.condicao,p:+p.preco,promo:+p.promo,img:p.img,cores:p.cores||[],arm:p.armazenamento,bat:p.bateria,gr:p.grade,gar:p.garantia,ac:p.acompanha,ob:p.obs,on:true}))};
    }catch(e){}
  }
  return base;
}
""")
# tracking -> Supabase
cut("var slug=n=>","document.addEventListener('click',e=>{if(e.target.closest('[data-wa]'))zap()});\n","""var slug=n=>n.toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
var vid=()=>{try{var v=localStorage.getItem('dd_v');if(!v){v=Math.random().toString(36).slice(2)+Date.now().toString(36);localStorage.setItem('dd_v',v)}return v}catch(e){return 'anon'}};
function ev(t,pd,ob){try{var s=D&&D.config.sb;if(!s||!s.key||/COLE/.test(s.key)||localStorage.getItem('dd_nt'))return;fetch(s.url+'/rest/v1/eventos',{method:'POST',headers:{apikey:s.key,Authorization:'Bearer '+s.key,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({tipo:t,produto:pd||null,visitante:vid(),objetivo:ob||null}),keepalive:true}).catch(()=>{})}catch(e){}}
function zap(){ev('zap')}
function track(){try{if(sessionStorage.getItem('dd_s'))return;sessionStorage.setItem('dd_s','1');ev('visita')}catch(e){}}
document.addEventListener('click',e=>{if(e.target.closest('[data-wa]'))zap()});
""")
# remove senha antiga do rodape: agora o painel tem login proprio
cut("var sha=async s=>","m.showModal();$('sw').focus()};\n","")
rep('<a href="#" id="adm"','<a href="admin.html" id="adm"')
rep("hit('interesse');hit('i-'+slug(p.n));","ev('interesse',p.n);")
rep("zap();hit('pedidos');hit(buy?'compras':'orcamentos');","zap();ev('pedido',p.n,buy?'compra':'orcamento');")
# aba Revenda
rep('<div class="perks">','<div class="row" id="tbs" style="margin-top:18px"><button class="chip on" data-t="v">📱 Catálogo</button><button class="chip" data-t="r">🏷 Revenda</button></div>\n  <div class="perks" id="perks">')
rep('<div class="tools">','<div class="tools" id="tools">')
rep('<div class="more">','<div class="more" id="mor">')
rep('</main>','<section id="rev" hidden></section>\n</main>')
rep("button{font-family:inherit}\n",""".rl h2{font-size:22px;margin:10px 0 6px}.rl p{color:var(--mut);font-size:14px;margin-bottom:8px}
.rl input{padding:11px;border:1px solid var(--line);border-radius:12px;margin:8px 0;width:100%;max-width:320px;display:block;font:inherit}
.rr{display:flex;gap:12px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:16px;padding:10px;margin-bottom:10px}
.rr img{width:56px;height:56px;object-fit:contain;background:#f1f1ef;border-radius:10px}
.ri{flex:1;display:flex;flex-direction:column;min-width:0}.ri small{color:var(--mut);font-size:12px}
.qt{width:68px;padding:9px;border:1px solid var(--line);border-radius:10px;font-size:15px}
.rbar{position:sticky;bottom:0;background:#fffffff2;border:1px solid var(--line);border-radius:16px;padding:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:12px 0 40px}
.rbar input{flex:1;min-width:150px;padding:10px;border:1px solid var(--line);border-radius:10px;font:inherit}
.err{color:#b91c1c;font-size:13px;width:100%}
button{font-family:inherit}
""")
rv=r'''var RV=[];
function tab(t){var r=t==='r';$('tbs').querySelectorAll('.chip').forEach(x=>x.classList.toggle('on',x.dataset.t===t));['perks','tools','count','grid'].forEach(i=>$(i).style.display=r?'none':'');$('mor').style.display=r?'none':'';$('rev').hidden=!r;if(r)revInit();else render()}
$('tbs').onclick=e=>{var b=e.target.closest('.chip');if(b)tab(b.dataset.t)};
function revLogin(m){$('rev').innerHTML='<div class="rl"><h2>🏷 Área de revenda</h2><p>Digite o código de revenda para ver os preços especiais para lojistas.</p><input id="rc" type="password" placeholder="Código de revenda" autocomplete="off"><p id="re" class="err">'+(m||'')+'</p><button class="btn" id="rb">Entrar</button></div>';$('rb').onclick=()=>revLoad($('rc').value.trim());$('rc').onkeydown=e=>{if(e.key==='Enter')revLoad(e.target.value.trim())}}
function revInit(){if(!D._sb){$('rev').innerHTML='<div class="empty">A aba de revenda ainda não está ativa.</div>';return}
  if(RV.length)return revDraw();var c='';try{c=sessionStorage.getItem('dd_rc')||''}catch(e){}if(c)revLoad(c,1);else revLogin()}
function revLoad(code,silent){var s=D.config.sb;if(!code)return;fetch(s.url+'/rest/v1/rpc/revenda_lista',{method:'POST',headers:{apikey:s.key,Authorization:'Bearer '+s.key,'Content-Type':'application/json'},body:JSON.stringify({codigo:code})}).then(r=>r.ok?r.json():Promise.reject()).then(j=>{RV=j;try{sessionStorage.setItem('dd_rc',code)}catch(e){}ev('revenda');revDraw()}).catch(()=>{try{sessionStorage.removeItem('dd_rc')}catch(e){}revLogin(silent?'':'Código inválido.')})}
function revDraw(){
  $('rev').innerHTML='<div class="rl"><h2>🏷 Revenda</h2><p>Preços especiais para lojistas. Informe a quantidade e envie o pedido pelo WhatsApp.</p></div>'+RV.map((p,i)=>'<div class="rr"><img src="'+(p.img||PH)+'" alt="" onerror="fb(this)"><div class="ri"><b>'+p.nome+'</b><small>'+[p.detalhes,p.bateria?'🔋 '+p.bateria+'%':'',p.condicao].filter(Boolean).join(' · ')+'</small><strong>'+(p.preco_revenda?brl(+p.preco_revenda):'Consulte')+'</strong></div><input class="qt" type="number" min="0" value="0" data-i="'+i+'" aria-label="Quantidade"></div>').join('')
   +'<div class="rbar"><b id="rt">Total: R$ 0,00</b><input id="rn" placeholder="Seu nome / empresa"><button class="btn" id="rs">Enviar pedido de revenda</button><p id="rer" class="err"></p></div>';
  var items=()=>[].slice.call($('rev').querySelectorAll('.qt')).map(q=>({p:RV[q.dataset.i],q:parseInt(q.value)||0})).filter(x=>x.q>0);
  $('rev').oninput=e=>{if(e.target.classList.contains('qt'))$('rt').textContent='Total: '+brl(items().reduce((a,x)=>a+(+x.p.preco_revenda||0)*x.q,0))};
  $('rs').onclick=()=>{var it=items(),n=$('rn').value.trim();if(!it.length)return $('rer').textContent='Informe a quantidade de pelo menos um aparelho.';if(!n)return $('rer').textContent='Informe seu nome ou empresa.';
    var tot=it.reduce((a,x)=>a+(+x.p.preco_revenda||0)*x.q,0),L=['🏷 *PEDIDO DE REVENDA — '+D.config.nome+'*','','👤 *Nome/Empresa:* '+n,'📦 *Itens:*'].concat(it.map(x=>'• '+x.q+'x '+x.p.nome+(x.p.detalhes?' ('+x.p.detalhes+')':'')+' — '+(x.p.preco_revenda?brl(+x.p.preco_revenda):'sob consulta'))).concat(['','💰 *Total:* '+brl(tot)+(it.some(x=>!x.p.preco_revenda)?' (+ itens sob consulta)':''),'','Aguardo a confirmação de disponibilidade. 🙌']);
    zap();window.open(wa(L.join('\n')),'_blank')}
}
'''
rep("function pick(",rv+"function pick(")
open('site/index.html','w',encoding='utf-8').write(s)
# ---- gen.py: config.sb ----
g=open('gen.py',encoding='utf-8').read()
if 'sb=dict' not in g:
    g=g.replace("D=dict(config=dict(cid=cid,","D=dict(config=dict(sb=dict(url='https://tnmggsriokdmksztgoch.supabase.co',key='COLE_AQUI_A_CHAVE_PUBLICA'),cid=cid,")
    g=g.replace("    if f=='index':s=s.replace(\"location.href='admin.html'\",\"window.open('https://claude.ai/artifact/K42tbx5HUCYoFkojpbWpBm','_blank')\")\n","    if f=='index':s=s.replace('href=\"admin.html\" id=\"adm\"','href=\"https://claude.ai/artifact/K42tbx5HUCYoFkojpbWpBm\" target=\"_blank\" id=\"adm\"')\n")
    open('gen.py','w',encoding='utf-8').write(g)
