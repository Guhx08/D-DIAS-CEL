s=open('site/index.html',encoding='utf-8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:50]
    s=s.replace(a,b)
css='''dialog{border:0;border-radius:20px;padding:0;width:min(460px,94vw);max-height:92vh;overflow:auto;color:var(--ink)}
dialog::backdrop{background:#0009}
.md{padding:20px}
.md h3{font-size:18px}
.mh{display:flex;gap:12px;align-items:center;margin-bottom:6px}
.mh img{width:76px;height:76px;object-fit:contain;background:#f1f1ef;border-radius:12px}
.mh small{color:var(--mut)}.mh s{color:var(--mut);font-size:13px}
.md label{display:block;font-size:12px;font-weight:700;color:var(--mut);margin:14px 0 6px}
.opts{display:flex;gap:8px;flex-wrap:wrap}
.op{padding:9px 14px;border-radius:999px;border:1px solid var(--line);background:#fff;font:inherit;font-size:13px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:7px}
.op.on{border-color:var(--o);background:#fff3e8;color:var(--o2)}
.op i{width:14px;height:14px;border-radius:50%;border:1px solid #0003}
.md input{width:100%;padding:11px 12px;border:1px solid var(--line);border-radius:12px;font:inherit;font-size:14px}
.x{float:right;background:none;border:0;font-size:28px;line-height:1;cursor:pointer;color:var(--mut)}
button{font-family:inherit}
@media(max-width:700px){dialog{margin:auto 0 0;width:100vw;max-width:100vw;border-radius:20px 20px 0 0}}
'''
rep("@media(max-width:700px){.sl{",css+"@media(max-width:700px){.sl{")
rep("<script>\nvar $=","<dialog id=\"md\"></dialog>\n<script>\nvar $=")
rep("""p.cores.map(c=>'<i style="background:'+c+'"></i>').join('')""","""p.cores.map(c=>{c=cor(c);return '<i style="background:'+c.h+'" title="'+c.n+'"></i>'}).join('')""")
rep("""<a class="btn" target="_blank" rel="noopener" href="'+wa('Olá! Tenho interesse no '+p.n+' ('+p.c+') por '+brl(v)+'. Ainda está disponível?')+'">Tenho interesse</a>""","""<button class="btn" data-o="'+D.produtos.indexOf(p)+'">Tenho interesse</button>""")
js=r'''var CN={'#b8aea4':'Bege','#4a90e2':'Azul','#1c1c1e':'Preto','#7a2a35':'Vinho','#eeeeee':'Branco','#f0f0f0':'Branco','#e6cf9f':'Dourado','#e0752f':'Laranja','#a8c5ae':'Verde','#8a8a8a':'Cinza','#888888':'Cinza'};
var cor=c=>{var a=String(c).split('|');return{h:a[0],n:a[1]||CN[a[0].toLowerCase()]||'Cor'}};
function order(p){
  var v=pr(p),pm=v<p.p,cs=(p.cores||[]).map(cor),m=$('md'),O={cor:cs.length===1?cs[0].n:'',pg:'Pix',en:'Receber em casa'},nm='';
  try{nm=localStorage.getItem('dd_nome')||''}catch(e){}
  var g=(k,a)=>'<div class="opts" data-g="'+k+'">'+a.map(x=>'<button type="button" class="op'+(O[k]===x.n?' on':'')+'" data-v="'+x.n+'">'+(x.h?'<i style="background:'+x.h+'"></i>':'')+x.n+'</button>').join('')+'</div>';
  m.innerHTML='<div class="md"><button class="x" data-x aria-label="Fechar">×</button><div class="mh"><img src="'+(p.img||PH)+'" alt=""><div><h3>'+p.n+'</h3><small>'+p.c+(p.e?' · '+p.e:'')+'</small><br><strong>'+brl(v)+'</strong>'+(pm?' <s>'+brl(p.p)+'</s>':'')+'</div></div>'
   +(cs.length?'<label>Cor</label>'+g('cor',cs):'')
   +'<label>Pagamento</label>'+g('pg',[{n:'Pix'},{n:'Cartão'}])
   +'<label>Entrega</label>'+g('en',[{n:'Receber em casa'},{n:'Retirar na loja'}])
   +'<div id="bf"><label>Bairro / endereço (opcional)</label><input id="bai" placeholder="Ex.: Centro, Osasco"></div>'
   +'<label>Seu nome</label><input id="nom" value="'+nm.replace(/"/g,'&quot;')+'" placeholder="Como podemos te chamar?">'
   +'<label>Observação (opcional)</label><input id="obs" placeholder="Ex.: tenho um aparelho para dar na troca">'
   +'<p id="er" style="color:#b91c1c;font-size:13px;margin-top:10px"></p><button class="btn" id="go" style="width:100%;justify-content:center;margin-top:8px">Enviar pedido pelo WhatsApp</button></div>';
  m.onclick=e=>{var t=e.target;
    if(t===m||t.hasAttribute('data-x'))return m.close();
    var b=t.closest('.op');
    if(b){var gr=b.parentNode.dataset.g;O[gr]=b.dataset.v;b.parentNode.querySelectorAll('.op').forEach(x=>x.classList.toggle('on',x===b));if(gr==='en')$('bf').hidden=O.en!=='Receber em casa'}
    if(t.id==='go'){var n=$('nom').value.trim();
      if(cs.length>1&&!O.cor)return $('er').textContent='Escolha a cor do aparelho.';
      if(!n)return $('er').textContent='Informe seu nome.';
      try{localStorage.setItem('dd_nome',n)}catch(x){}
      var bai=$('bai').value.trim(),ob=$('obs').value.trim();
      var L=['🛒 *NOVO PEDIDO — '+D.config.nome+'*','','📱 *Produto:* '+p.n,'🔹 *Condição:* '+p.c,p.e?'💾 *Detalhes:* '+p.e:null,O.cor?'🎨 *Cor:* '+O.cor:null,'💰 *Valor:* '+brl(v)+(pm?' (promoção, de '+brl(p.p)+')':''),'💳 *Pagamento:* '+O.pg,'🚚 *Entrega:* '+O.en+(O.en==='Receber em casa'&&bai?' — '+bai:''),'👤 *Nome:* '+n,ob?'📝 *Obs.:* '+ob:null,'','Aguardo a confirmação de disponibilidade. 🙌'];
      window.open(wa(L.filter(x=>x!==null).join('\n')),'_blank');m.close()}};
  m.showModal();
}
$('grid').addEventListener('click',e=>{var b=e.target.closest('[data-o]');if(b)order(D.produtos[b.dataset.o])});
'''
rep("function pick(",js+"function pick(")
open('site/index.html','w',encoding='utf-8').write(s)
a=open('site/admin.html',encoding='utf-8').read()
old="<label>Cores (códigos separados por vírgula)</label>"
assert old in a
a=a.replace(old,"<label>Cores (código ou código|Nome, separados por vírgula)</label>")
open('site/admin.html','w',encoding='utf-8').write(a)
g=open('gen.py',encoding='utf-8').read()
for h,n in [("'#b8aea4'","Bege"),("'#4a90e2'","Azul"),("'#1c1c1e'","Preto"),("'#7a2a35'","Vinho"),("'#eeeeee'","Branco"),("'#e6cf9f'","Dourado"),("'#e0752f'","Laranja"),("'#a8c5ae'","Verde"),("'#8a8a8a'","Cinza")]:
    g=g.replace(h,h[:-1]+"|"+n+"'",1)
g=g.replace("['#f0f0f0',K]","['#f0f0f0|Branco',K]").replace("[Gr])]","['#cccccc|Branco'])]")
open('gen.py','w',encoding='utf-8').write(g)
