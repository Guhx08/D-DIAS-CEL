def ed(f,fn):
    s=open(f,encoding='utf-8').read();s=fn(s);open(f,'w',encoding='utf-8').write(s)
def rep(s,a,b):
    assert s.count(a)==1,a[:60];return s.replace(a,b)
def idx(s):
    s=rep(s,"sem aviso prévio.</div>\n</div></footer>","sem aviso prévio.</div>\n  <a href=\"#\" id=\"adm\" style=\"color:#8b919b;font-size:12px\">🔒 Área do administrador</a>\n</div></footer>")
    js=r'''var sha=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
$('adm').onclick=e=>{e.preventDefault();var m=$('md');
  m.innerHTML='<div class="md"><button class="x" data-x aria-label="Fechar">×</button><h3>🔒 Área do administrador</h3><label>Senha</label><input id="sw" type="password" placeholder="Digite a senha" autocomplete="current-password"><p id="er" style="color:#b91c1c;font-size:13px;margin-top:10px"></p><button class="btn" id="go" style="width:100%;justify-content:center;margin-top:8px">Entrar</button></div>';
  var enter=async()=>{var h=await sha($('sw').value);if(D&&h===D.config.sh){try{sessionStorage.setItem('dd_ok','1')}catch(x){}location.href='admin.html'}else $('er').textContent='Senha incorreta.'};
  m.onclick=ev=>{var t=ev.target;if(t===m||t.hasAttribute('data-x'))m.close();if(t.id==='go')enter()};
  m.onkeydown=ev=>{if(ev.key==='Enter'&&ev.target.id==='sw')enter()};
  m.showModal();$('sw').focus()};
'''
    return rep(s,"function pick(",js+"function pick(")
ed('site/index.html',idx)
def adm(s):
    s=rep(s,"const SENHA='dias2026'; // TROQUE a senha aqui\n","")
    a=s.index("function login(){");b=s.index("const esc=")
    new='''const sha=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('');
const enter=()=>{try{sessionStorage.setItem('dd_ok','1')}catch(e){}$('login').hidden=true;$('app').hidden=false;load().then(d=>{D=d;draw()})};
async function login(){const d=await load().catch(()=>null),h=await sha($('pw').value);
  if(d&&h===d.config.sh)enter();else $('err').textContent='Senha incorreta'}
$('ok').onclick=login;$('pw').onkeydown=e=>e.key==='Enter'&&login();
try{if(sessionStorage.getItem('dd_ok'))enter()}catch(e){}
'''
    s=s[:a]+new+s[b:]
    s=rep(s,").join('')}\nfunction draw(){",").join('')+'<div style=\"margin-top:16px\"><label>Nova senha do painel (vazio = manter a atual)</label><input id=\"nsw\" type=\"password\" autocomplete=\"new-password\"></div>'}\nfunction draw(){")
    s=rep(s,"$('tabs').onclick=","$('ll').addEventListener('change',async e=>{if(e.target.id==='nsw'&&e.target.value){D.config.sh=await sha(e.target.value);e.target.value='';save();alert('Senha alterada! Ela passa a valer no site depois que você baixar e publicar o dados.json.')}});\n$('tabs').onclick=")
    s=rep(s,'<a class="b g" href="index.html?preview=1"','<a class="b g" href="index.html">← Site</a>\n  <a class="b g" href="index.html?preview=1"')
    return s
ed('site/admin.html',adm)
def gen(s):
    s=rep(s,"logo=LOGO),banners","logo=LOGO,sh=__import__('hashlib').sha256(b'dias2026').hexdigest()),banners")
    s=rep(s,"    i=s.rindex('<script>')","    if f=='index':s=s.replace(\"location.href='admin.html'\",\"window.open('https://claude.ai/artifact/K42tbx5HUCYoFkojpbWpBm','_blank')\")\n    i=s.rindex('<script>')")
    return s
ed('gen.py',gen)
