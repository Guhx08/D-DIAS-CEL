import re,json
def R(s,a,b,n=1):
    assert s.count(a)==n,(s.count(a),a[:70]);return s.replace(a,b)
def cut(s,a,b,new=''):
    i=s.index(a);j=s.index(b,i)+len(b);return s[:i]+new+s[j:]
# ================= SQL =================
q=open('db/schema.sql',encoding='utf-8').read()
q=R(q,"  margem_revenda numeric not null default 8,       -- % sobre o custo para o preço de revenda\n","")
q=R(q,"create table if not exists public.config_privada (id int primary key default 1 check (id=1), codigo_revenda_hash text);\n","")
q=R(q,"  grade text, garantia text, acompanha text, obs text,\n","  grade text, garantia text, acompanha text, obs text,\n  origem text not null default 'loja' check (origem in ('loja','revenda')),   -- revenda = aparelho de terceiros\n")
q=R(q,"custo numeric(10,2), preco_revenda numeric(10,2),","custo numeric(10,2), dono_nome text, dono_contato text,")
q=R(q,"alter table public.config_privada enable row level security;\n","")
q=R(q,"create policy cfgpriv_adm on public.config_privada for all to authenticated using (public.is_admin()) with check (public.is_admin());\n","")
q=R(q,"public.setup_admin, public.config_privada, public.fornecedores","public.setup_admin, public.fornecedores")
q=R(q,"public.produtos_privado, public.config_privada to authenticated;","public.produtos_privado to authenticated;",2)
q=cut(q,"-- ---------- aba de REVENDA","grant execute on function public.revenda_lista(text) to anon, authenticated;\n")
q=re.sub(r"create policy (\w+) on ([\w.]+) ",lambda m:f"drop policy if exists {m.group(1)} on {m.group(2)};\ncreate policy {m.group(1)} on {m.group(2)} ",q)
q=R(q,"-- ---------- fotos (Storage) ----------","""-- ---------- atualizações (seguro rodar de novo) ----------
alter table public.produtos add column if not exists origem text not null default 'loja';
alter table public.produtos_privado add column if not exists dono_nome text;
alter table public.produtos_privado add column if not exists dono_contato text;
alter table public.produtos_privado drop column if exists preco_revenda;
alter table public.config drop column if exists margem_revenda;
drop function if exists public.revenda_lista(text);
drop table if exists public.config_privada;

-- ---------- fotos (Storage) ----------""")
open('db/schema.sql','w',encoding='utf-8').write(q)
D=json.load(open('site/dados.json',encoding='utf-8'));Q=lambda s:"'"+str(s).replace("'","''")+"'"
setup=open('db/codes.txt').read().split()[0];c=D['config']
L=["-- ===== dados iniciais (só entram se o banco estiver vazio) =====",
f"insert into public.config(id,nome,cidade,wa,ig,logo) values (1,{Q(c['nome'])},{Q(c['cidade'])},{Q(c['wa'])},{Q(c['ig'])},{Q(c['logo'])}) on conflict (id) do nothing;",
f"insert into public.setup_admin(id,code_hash) select 1,encode(digest({Q(setup)},'sha256'),'hex') where not exists(select 1 from public.admins) on conflict (id) do nothing;"]
rows=[f"({Q(p['n'])},{Q(p['e'])},{Q(p['c'])},{p['p']},0,{Q(p['img'])},{Q(json.dumps(p['cores'],ensure_ascii=False))}::jsonb,true,{i})" for i,p in enumerate(D['produtos'],1)]
L.append("insert into public.produtos(nome,detalhes,condicao,preco,promo,img,cores,ativo,ordem)\nselect * from (values\n"+",\n".join(rows)+"\n) as v(nome,detalhes,condicao,preco,promo,img,cores,ativo,ordem)\nwhere not exists (select 1 from public.produtos);")
b=[f"(true,{Q(x['t'])},{Q(x['s'])},{Q(x['b'])},{Q(x['q'])},{Q(x['bg'])},{Q(x['img'])},{i})" for i,x in enumerate(D['banners'],1)]
L.append("insert into public.banners(ativo,titulo,subtitulo,botao,mensagem,cor,img,ordem)\nselect * from (values\n"+",\n".join(b)+"\n) as v(ativo,titulo,subtitulo,botao,mensagem,cor,img,ordem)\nwhere not exists (select 1 from public.banners);")
open('db/seed.sql','w',encoding='utf-8').write("\n".join(L)+"\n")
# ================= ADMIN =================
t=open('admin_sb.tpl',encoding='utf-8').read()
t=R(t,'<button class="qk" data-go="revenda"><i>🏷</i>Revenda</button>','<button class="qk" data-go="produtos" data-flt="revenda"><i>🏷</i>Revenda</button>')
t=cut(t,'<section class="v" id="v-revenda" hidden>','</section>\n\n')
t=R(t,'<h2>Aparelhos</h2></div>','<h2>Aparelhos</h2></div>\n  <div class="row" id="flt" style="margin-bottom:12px"><button class="chip on" data-v="all">Todos</button><button class="chip" data-v="loja">Da loja</button><button class="chip" data-v="revenda">🏷 Revenda (de terceiros)</button></div>')
t=R(t,"textarea{width:100%;",".chip{padding:9px 16px;border-radius:999px;background:var(--c);border:1px solid var(--ln);font-size:13px;font-weight:600;cursor:pointer;color:var(--tx)}.chip.on{background:var(--o);border-color:var(--o);color:#fff}.row{display:flex;gap:8px;flex-wrap:wrap}\ntextarea{width:100%;")
t=R(t,"let SB,tok,rt,exp,P=[]","let FLT='all',SB,tok,rt,exp,P=[]")
t=R(t,"$('lp').innerHTML=P.map(p=>","$('lp').innerHTML=P.filter(p=>FLT==='all'||(p.origem||'loja')===FLT).map(p=>")
t=R(t,"show(g.dataset.go);if(g.dataset.f)","show(g.dataset.go);if(g.dataset.flt)setFlt(g.dataset.flt);if(g.dataset.f)")
t=R(t,"// ---------- home ----------","function setFlt(v){FLT=v;$('flt').querySelectorAll('.chip').forEach(x=>x.classList.toggle('on',x.dataset.v===v));drawP()}\n$('flt').onclick=e=>{const b=e.target.closest('.chip');if(b)setFlt(b.dataset.v)};\n// ---------- home ----------")
t=R(t,"x.custo=v.custo;x.preco_revenda=v.preco_revenda;x.fornecedor_id=v.fornecedor_id","x.custo=v.custo;x.dono_nome=v.dono_nome;x.dono_contato=v.dono_contato;x.fornecedor_id=v.fornecedor_id")
t=R(t,"${inp('Custo (R$) — só você vê','v','custo',p.custo??'','type=\"number\" step=\"0.01\" data-n')}${inp('Preço de revenda (R$)','v','preco_revenda',p.preco_revenda??'','type=\"number\" step=\"0.01\" data-n')}",
 "<div><label>Onde aparece</label><select data-t=\"p\" data-k=\"origem\"><option value=\"loja\" ${p.origem!=='revenda'?'selected':''}>Catálogo da loja</option><option value=\"revenda\" ${p.origem==='revenda'?'selected':''}>🏷 Revenda (de terceiros)</option></select></div>${inp('Custo / valor do dono (R$) — só você vê','v','custo',p.custo??'','type=\"number\" step=\"0.01\" data-n')}${inp('Dono do aparelho (revenda) — só você vê','v','dono_nome',p.dono_nome??'')}${inp('Contato do dono — só você vê','v','dono_contato',p.dono_contato??'')}")
t=R(t,"if(v==='revenda'){$('rm2').value=C.margem_revenda??8}","")
t=cut(t,"$('rsv').onclick=","}catch(e){toast('Erro: '+e.message,1)}};\n")
# importador: modo "dono"
t=R(t,'<option value="custo">o custo do fornecedor</option></select></div>','<option value="custo">o custo do fornecedor</option><option value="dono">o valor que o dono quer receber (revenda de terceiros)</option></select></div>')
t=R(t,"<div><label>Margem sobre o custo (%)</label><input id=\"wg\" type=\"number\" value=\"15\"></div>\n    </div>","<div><label>Margem / comissão (%)</label><input id=\"wg\" type=\"number\" value=\"15\"></div>\n    </div>\n    <div id=\"wd\" class=\"f\" style=\"margin-top:12px\" hidden><div><label>Nome do dono do aparelho</label><input id=\"wdn\"></div><div><label>Contato do dono</label><input id=\"wdc\"></div></div>")
t=R(t,"$('wm').value==='custo'?Math.ceil","$('wm').value!=='venda'?Math.ceil")
t=R(t,"${$('wm').value==='custo'?'Custo':'Valor'}","${$('wm').value!=='venda'?'Custo / dono':'Valor'}")
t=R(t,"$('wm').onchange=()=>{R.forEach(r=>r.venda=null);","$('wm').onchange=()=>{$('wd').hidden=$('wm').value!=='dono';R.forEach(r=>r.venda=null);")
t=R(t,"const ex=P.find(p=>p.nome===r.nome&&","const org=mode==='dono'?'revenda':'loja',ex=P.find(p=>(p.origem||'loja')===org&&p.nome===r.nome&&")
t=R(t,"cores,img,ativo:true,ordem:--o}","cores,img,ativo:true,origem:org,ordem:--o}")
t=R(t,"if(mode==='custo'||forn){await rest('POST','produtos_privado?on_conflict=produto_id',{produto_id:p.id,custo:mode==='custo'?r.v:null,fornecedor_id:forn,atualizado_em:new Date().toISOString()},{Prefer:'resolution=merge-duplicates,return=minimal'});if(mode==='custo')p.custo=r.v}",
 "if(mode!=='venda'||forn){await rest('POST','produtos_privado?on_conflict=produto_id',{produto_id:p.id,custo:mode!=='venda'?r.v:null,fornecedor_id:forn,dono_nome:mode==='dono'?($('wdn').value.trim()||null):undefined,dono_contato:mode==='dono'?($('wdc').value.trim()||null):undefined,atualizado_em:new Date().toISOString()},{Prefer:'resolution=merge-duplicates,return=minimal'});if(mode!=='venda')p.custo=r.v}")
t=R(t,"${r.nome}","${r.nome}",0) if False else t
open('admin_sb.tpl','w',encoding='utf-8').write(t)
st=open('admin_new.html',encoding='utf-8').read();style=st[st.index('<style>')+7:st.index('</style>')]
open('site/admin.html','w',encoding='utf-8').write(t.replace('{{STYLE}}',style))
# ================= SITE =================
s=open('site/index.html',encoding='utf-8').read()
s=cut(s,"var RV=[];\nfunction tab(t){","function pick(","""function tab(t){S.tab=t;$('tbs').querySelectorAll('.chip').forEach(x=>x.classList.toggle('on',x.dataset.t===t));$('rvb').hidden=t!=='r';S.n=8;render();if(t==='r')ev('revenda')}
$('tbs').onclick=e=>{var b=e.target.closest('.chip');if(b)tab(b.dataset.t)};
function sell(){var m=$('md'),O={es:''};
  m.innerHTML='<div class="md"><button class="x" data-x aria-label="Fechar">×</button><h3>Quero revender o meu iPhone</h3><p style="color:var(--mut);font-size:13px;margin-top:6px">Conte sobre o aparelho. A gente avalia e anuncia para você.</p>'
   +'<label>Modelo</label><input id="sm" placeholder="Ex.: iPhone 13 Pro"><label>Armazenamento</label><input id="sa" placeholder="Ex.: 128GB"><label>Saúde da bateria (%)</label><input id="sb" type="number" placeholder="Ex.: 89">'
   +'<label>Estado do aparelho</label><div class="opts" data-g="es">'+['Ótimo','Bom','Com marcas de uso'].map(x=>'<button type="button" class="op" data-v="'+x+'">'+x+'</button>').join('')+'</div>'
   +'<label>Quanto você quer receber (R$)</label><input id="sv" type="number" placeholder="Ex.: 2500"><label>Seu nome</label><input id="sn" placeholder="Como podemos te chamar?">'
   +'<p id="er" style="color:#b91c1c;font-size:13px;margin-top:10px"></p><button class="btn" id="go" style="width:100%;justify-content:center;margin-top:8px">Enviar pelo WhatsApp</button></div>';
  m.onclick=e=>{var t=e.target;if(t===m||t.hasAttribute('data-x'))return m.close();var b=t.closest('.op');
    if(b){O.es=b.dataset.v;b.parentNode.querySelectorAll('.op').forEach(x=>x.classList.toggle('on',x===b))}
    if(t.id==='go'){var md=$('sm').value.trim(),n=$('sn').value.trim();if(!md)return $('er').textContent='Informe o modelo do aparelho.';if(!n)return $('er').textContent='Informe seu nome.';
      var bt=$('sb').value.trim(),vl=parseFloat($('sv').value),L=['💬 *QUERO REVENDER MEU APARELHO — '+D.config.nome+'*','','📱 *Modelo:* '+md,$('sa').value.trim()?'💾 *Armazenamento:* '+$('sa').value.trim():null,bt?'🔋 *Bateria:* '+bt+'%':null,O.es?'✨ *Estado:* '+O.es:null,vl?'💰 *Quero receber:* '+brl(vl):null,'👤 *Nome:* '+n,'','Pode avaliar e anunciar para mim? 🙌'];
      zap();window.open(wa(L.filter(x=>x!==null).join('\\n')),'_blank');m.close()}};
  m.showModal()}
$('sell').onclick=sell;
function pick(""")
s=R(s,'<section id="rev" hidden></section>\n</main>','</main>')
s=R(s,'<button class="chip" data-t="r">🏷 Revenda</button></div>','<button class="chip" data-t="r">🏷 Revenda</button></div>\n  <div class="rvb" id="rvb" hidden><b>🏷 Revenda de aparelhos de outras pessoas</b><span>Aparelhos de particulares vendidos com a nossa intermediação. Quer vender o seu iPhone? A gente anuncia para você.</span><button class="btn" id="sell">Quero revender o meu</button></div>')
s=R(s,"S={cat:'all',","S={tab:'v',cat:'all',")
s=R(s,"D.produtos.filter(p=>p.on!==false&&","D.produtos.filter(p=>p.on!==false&&((p.or==='revenda')===(S.tab==='r'))&&")
s=R(s,"ob:p.obs,on:true}","ob:p.obs,or:p.origem,on:true}")
s=R(s,"'\">'+p.c+'</span>'","'\">'+(p.or==='revenda'?'🏷 ':'')+p.c+'</span>'")
s=R(s,"'📱 *Produto:* '+p.n,","p.or==='revenda'?'🏷 *Origem:* Revenda (aparelho de terceiros)':null,'📱 *Produto:* '+p.n,")
s=R(s,"button{font-family:inherit}\n",".rvb{display:flex;flex-direction:column;gap:6px;background:#fff7ed;border:1px solid #fed7aa;border-radius:16px;padding:14px;margin-top:12px;font-size:13px;color:#7a4a1e}.rvb[hidden]{display:none}.rvb b{font-size:15px;color:var(--ink)}.rvb .btn{align-self:flex-start;margin-top:4px}\nbutton{font-family:inherit}\n")
open('site/index.html','w',encoding='utf-8').write(s)
