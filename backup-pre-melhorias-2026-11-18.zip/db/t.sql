\set ON_ERROR_STOP off
\echo '== anon: catalogo =='
set role anon; select count(*) as produtos from produtos; select count(*) as banners from banners; select nome from config;
\echo '== anon NAO pode ler custo/fornecedor/admin/eventos =='
select count(*) from produtos_privado;
select count(*) from fornecedores;
select count(*) from eventos;
select * from setup_admin;
\echo '== anon pode registrar evento =='
insert into eventos(tipo,produto,visitante) values ('visita',null,'v1');
insert into eventos(tipo,produto,objetivo) values ('pedido','iPhone 15','compra');
\echo '== anon NAO pode editar produto nem se promover =='
update produtos set preco=1; select claim_admin('x');
\echo '== revenda: codigo errado e certo =='
select revenda_lista('errado');
reset role;
