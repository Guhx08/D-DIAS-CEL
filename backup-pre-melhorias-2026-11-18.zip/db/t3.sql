\set ON_ERROR_STOP off
insert into produtos(nome,detalhes,condicao,preco,origem,ordem) values ('iPhone 13 (de terceiros)','128GB · Azul','Semi',2300,'revenda',99);
insert into produtos_privado(produto_id,custo,dono_nome,dono_contato) select id,2000,'Maria','11 99999-0000' from produtos where origem='revenda';
set role anon;
\echo '-- visitante (anon): ve a revenda no catalogo --'
select nome, origem from produtos where origem='revenda';
\echo '-- visitante NAO ve dono/custo (esperado: permission denied) --'
select dono_nome from produtos_privado;
\echo '-- visitante NAO consegue editar (esperado: 0 linhas) --'
update produtos set preco=1 where origem='revenda'; select preco from produtos where origem='revenda';
\echo '-- visitante registra evento de revenda (esperado: INSERT 0 1) --'
insert into eventos(tipo,visitante) values ('revenda','v1');
reset role;
