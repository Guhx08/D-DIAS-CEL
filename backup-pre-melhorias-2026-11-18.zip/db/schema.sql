-- =====================================================================
-- D'DIAS CEL — banco de dados (Supabase)  |  rode inteiro no SQL Editor
-- =====================================================================
create extension if not exists pgcrypto;

-- ---------- administradores ----------
create table if not exists public.admins (email text primary key);
create table if not exists public.setup_admin (id int primary key default 1 check (id=1), code_hash text not null);
alter table public.admins enable row level security;
alter table public.setup_admin enable row level security;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public, extensions as $$
  select exists(select 1 from public.admins where lower(email)=lower(coalesce(auth.jwt()->>'email','')))
$$;

-- primeiro acesso: quem cria a conta e digita o código vira administrador (uso único)
create or replace function public.claim_admin(code text) returns boolean
language plpgsql security definer set search_path=public, extensions as $$
declare em text := lower(coalesce(auth.jwt()->>'email',''));
begin
  if em='' then raise exception 'login necessario'; end if;
  if exists(select 1 from public.admins) then raise exception 'ja existe administrador'; end if;
  if not exists(select 1 from public.setup_admin where code_hash=encode(digest(code,'sha256'),'hex')) then
    raise exception 'codigo invalido'; end if;
  insert into public.admins(email) values (em);
  delete from public.setup_admin;
  return true;
end $$;

-- ---------- loja ----------
create table if not exists public.config (
  id int primary key default 1 check (id=1),
  nome text, cidade text, wa text, ig text, logo text,
  updated_at timestamptz default now());

create table if not exists public.fornecedores (
  id uuid primary key default gen_random_uuid(),
  nome text not null, contato text, margem numeric not null default 15, obs text,
  created_at timestamptz default now());

create table if not exists public.produtos (
  id uuid primary key default gen_random_uuid(),
  nome text not null, detalhes text default '', condicao text not null default 'Semi',
  preco numeric(10,2) not null default 0, promo numeric(10,2) not null default 0,
  img text default '', cores jsonb not null default '[]',
  ativo boolean not null default true, ordem int not null default 0,
  armazenamento text, bateria int check (bateria between 0 and 100),
  grade text, garantia text, acompanha text, obs text,
  origem text not null default 'loja' check (origem in ('loja','revenda')),   -- revenda = aparelho de terceiros
  created_at timestamptz default now(), updated_at timestamptz default now());

-- dados que o cliente NUNCA vê (custo, fornecedor, preço de revenda)
create table if not exists public.produtos_privado (
  produto_id uuid primary key references public.produtos(id) on delete cascade,
  custo numeric(10,2), dono_nome text, dono_contato text,
  fornecedor_id uuid references public.fornecedores(id) on delete set null,
  atualizado_em timestamptz default now());

create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  ativo boolean not null default true, titulo text, subtitulo text, botao text,
  mensagem text, cor text, img text, ordem int not null default 0);

create table if not exists public.eventos (
  id bigserial primary key,
  tipo text not null check (tipo in ('visita','zap','interesse','pedido','revenda')),
  produto text check (char_length(produto)<=80), visitante text check (char_length(visitante)<=64),
  objetivo text check (objetivo in ('orcamento','compra')),
  created_at timestamptz not null default now());
create index if not exists eventos_created on public.eventos(created_at);

-- ---------- segurança (RLS) ----------
alter table public.config enable row level security;
alter table public.fornecedores enable row level security;
alter table public.produtos enable row level security;
alter table public.produtos_privado enable row level security;
alter table public.banners enable row level security;
alter table public.eventos enable row level security;

drop policy if exists config_ler on public.config;
create policy config_ler on public.config for select to anon, authenticated using (true);
drop policy if exists config_adm on public.config;
create policy config_adm on public.config for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists produtos_ler on public.produtos;
create policy produtos_ler on public.produtos for select to anon, authenticated using (ativo or public.is_admin());
drop policy if exists produtos_adm on public.produtos;
create policy produtos_adm on public.produtos for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists banners_ler on public.banners;
create policy banners_ler on public.banners for select to anon, authenticated using (ativo or public.is_admin());
drop policy if exists banners_adm on public.banners;
create policy banners_adm on public.banners for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists priv_adm on public.produtos_privado;
create policy priv_adm on public.produtos_privado for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists forn_adm on public.fornecedores;
create policy forn_adm on public.fornecedores for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists ev_inserir on public.eventos;
create policy ev_inserir on public.eventos for insert to anon, authenticated with check (true);
drop policy if exists ev_ler on public.eventos;
create policy ev_ler on public.eventos for select to authenticated using (public.is_admin());

revoke all on public.admins, public.setup_admin, public.fornecedores, public.produtos_privado from anon;
revoke all on public.eventos from anon, authenticated;
grant insert on public.eventos to anon, authenticated;
grant select on public.eventos to authenticated;
grant usage, select on sequence public.eventos_id_seq to anon, authenticated;
grant select on public.config, public.produtos, public.banners to anon, authenticated;
grant insert, update, delete on public.config, public.produtos, public.banners, public.fornecedores, public.produtos_privado to authenticated;
grant select on public.fornecedores, public.produtos_privado to authenticated;
revoke all on function public.is_admin() from public; grant execute on function public.is_admin() to anon, authenticated;
revoke all on function public.claim_admin(text) from public; grant execute on function public.claim_admin(text) to authenticated;

-- ---------- estatísticas (só admin) ----------
create or replace function public.stats_resumo(dias int default 7) returns jsonb
language plpgsql stable security definer set search_path=public, extensions as $$
declare r jsonb; hoje date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select jsonb_build_object(
    'visitantes',(select count(distinct visitante) from eventos where tipo='visita'),
    'visitas',(select count(*) from eventos where tipo='visita'),
    'zap',(select count(*) from eventos where tipo='zap'),
    'interesse',(select count(*) from eventos where tipo='interesse'),
    'pedidos',(select count(*) from eventos where tipo='pedido'),
    'orcamentos',(select count(*) from eventos where tipo='pedido' and objetivo='orcamento'),
    'compras',(select count(*) from eventos where tipo='pedido' and objetivo='compra'),
    'revenda',(select count(*) from eventos where tipo='revenda'),
    'dias',(select coalesce(jsonb_agg(jsonb_build_object('dia',to_char(d,'YYYY-MM-DD'),
        'visitas',(select count(*) from eventos e where e.tipo='visita' and (e.created_at at time zone 'America/Sao_Paulo')::date=d),
        'zap',(select count(*) from eventos e where e.tipo='zap' and (e.created_at at time zone 'America/Sao_Paulo')::date=d)) order by d desc),'[]'::jsonb)
        from generate_series(hoje-(dias-1),hoje,interval '1 day') g(d0), lateral (select g.d0::date as d) x),
    'produtos',(select coalesce(jsonb_agg(jsonb_build_object('produto',produto,'n',n) order by n desc),'[]'::jsonb)
        from (select produto,count(*) n from eventos where tipo='interesse' and produto is not null group by produto order by n desc limit 10) q)
  ) into r;
  return r;
end $$;
revoke all on function public.stats_resumo(int) from public; grant execute on function public.stats_resumo(int) to authenticated;


-- ---------- atualizações (seguro rodar de novo) ----------
alter table public.produtos add column if not exists origem text not null default 'loja';
alter table public.produtos_privado add column if not exists dono_nome text;
alter table public.produtos_privado add column if not exists dono_contato text;
alter table public.produtos_privado drop column if exists preco_revenda;
alter table public.config drop column if exists margem_revenda;
drop function if exists public.revenda_lista(text);
drop table if exists public.config_privada;

-- ---------- fotos (Storage) ----------
insert into storage.buckets (id,name,public) values ('fotos','fotos',true) on conflict (id) do nothing;
drop policy if exists fotos_adm on storage.objects;
create policy fotos_adm on storage.objects for all to authenticated
  using (bucket_id='fotos' and public.is_admin()) with check (bucket_id='fotos' and public.is_admin());

-- ---------- endurecimento de permissões (aplicado no projeto) ----------
revoke insert, update, delete, truncate, references, trigger on public.config, public.produtos, public.banners from anon;
revoke truncate, references, trigger on all tables in schema public from authenticated;
revoke truncate, references, trigger on all tables in schema public from anon;
revoke all on function public.stats_resumo(int) from anon;
revoke all on function public.claim_admin(text) from anon;
alter default privileges in schema public revoke all on tables from anon;
alter default privileges in schema public revoke all on functions from anon;
