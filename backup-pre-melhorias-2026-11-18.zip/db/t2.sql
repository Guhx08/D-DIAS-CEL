\set ON_ERROR_STOP off
set request.jwt.claims = '{"email":"intruso@x.com","role":"authenticated"}';
\echo '== usuario logado QUALQUER (nao admin) =='
set role authenticated;
update produtos set preco=1;
select count(*) as custo from produtos_privado;
select claim_admin('codigo-errado');
select stats_resumo(7);
\echo '== claim com codigo certo (dono) =='
reset role; set request.jwt.claims = '{"email":"dono@loja.com","role":"authenticated"}'; set role authenticated;
select claim_admin('DD-W8E1CHYS') as virou_admin;
select is_admin();
select claim_admin('DD-W8E1CHYS');
\echo '== admin edita, define custo, promo =='
update produtos set promo=4000 where nome='iPhone 15 Pro Max';
select nome,preco,promo from produtos where promo>0;
insert into produtos_privado(produto_id,custo) select id,3800 from produtos where nome='iPhone 15 Pro Max';
insert into fornecedores(nome,margem) values ('Fornecedor A',12);
select count(*) as eventos_visiveis_admin from eventos;
select jsonb_pretty(stats_resumo(3)) ;
\echo '== segundo usuario nao vira admin =='
reset role; set request.jwt.claims = '{"email":"outro@x.com","role":"authenticated"}'; set role authenticated;
select claim_admin('DD-W8E1CHYS');
select is_admin();
\echo '== revenda =='
reset role; set role anon;
select jsonb_array_length(revenda_lista('REV-Z8FBC5')) as itens;
select r->>'nome' as nome, r->>'preco_revenda' as preco_revenda from jsonb_array_elements(revenda_lista('REV-Z8FBC5')) r where r->>'nome'='iPhone 15 Pro Max';
select r->>'preco_revenda' as sem_custo from jsonb_array_elements(revenda_lista('REV-Z8FBC5')) r where r->>'nome'='iPhone 12';
reset role;
