-- =====================================================================
-- D'DIAS CEL — banco de dados (Supabase)  |  rode inteiro no SQL Editor
-- =====================================================================
create extension if not exists pgcrypto;

-- ---------- administradores ----------
create table if not exists public.admins (email text primary key);
create table if not exists public.setup_admin (id int primary key default 1 check (id=1), code_hash text not null);
alter table public.admins enable row level security;
alter table public.setup_admin enable row level security;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.admins where lower(email)=lower(coalesce(auth.jwt()->>'email','')))
$$;

-- primeiro acesso: quem cria a conta e digita o código vira administrador (uso único)
create or replace function public.claim_admin(code text) returns boolean
language plpgsql security definer set search_path=public as $$
declare em text := lower(coalesce(auth.jwt()->>'email',''));
begin
  if em='' then raise exception 'login necessario'; end if;
  if exists(select 1 from public.admins) then raise exception 'ja existe administrador'; end if;
  if not exists(select 1 from public.setup_admin where code_hash=encode(digest(code,'sha256'),'hex')) then
    raise exception 'codigo invalido'; end if;
  insert into public.admins(email) values (em);
  delete from public.setup_admin;
  return true;
end $$;

-- ---------- loja ----------
create table if not exists public.config (
  id int primary key default 1 check (id=1),
  nome text, cidade text, wa text, ig text, logo text,
  margem_revenda numeric not null default 8,       -- % sobre o custo para o preço de revenda
  updated_at timestamptz default now());
create table if not exists public.config_privada (id int primary key default 1 check (id=1), codigo_revenda_hash text);

create table if not exists public.fornecedores (
  id uuid primary key default gen_random_uuid(),
  nome text not null, contato text, margem numeric not null default 15, obs text,
  created_at timestamptz default now());

create table if not exists public.produtos (
  id uuid primary key default gen_random_uuid(),
  nome text not null, detalhes text default '', condicao text not null default 'Semi',
  preco numeric(10,2) not null default 0, promo numeric(10,2) not null default 0,
  img text default '', cores jsonb not null default '[]',
  ativo boolean not null default true, ordem int not null default 0,
  armazenamento text, bateria int check (bateria between 0 and 100),
  grade text, garantia text, acompanha text, obs text,
  created_at timestamptz default now(), updated_at timestamptz default now());

-- dados que o cliente NUNCA vê (custo, fornecedor, preço de revenda)
create table if not exists public.produtos_privado (
  produto_id uuid primary key references public.produtos(id) on delete cascade,
  custo numeric(10,2), preco_revenda numeric(10,2),
  fornecedor_id uuid references public.fornecedores(id) on delete set null,
  atualizado_em timestamptz default now());

create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  ativo boolean not null default true, titulo text, subtitulo text, botao text,
  mensagem text, cor text, img text, ordem int not null default 0);

create table if not exists public.eventos (
  id bigserial primary key,
  tipo text not null check (tipo in ('visita','zap','interesse','pedido','revenda')),
  produto text check (char_length(produto)<=80), visitante text check (char_length(visitante)<=64),
  objetivo text check (objetivo in ('orcamento','compra')),
  created_at timestamptz not null default now());
create index if not exists eventos_created on public.eventos(created_at);

-- ---------- segurança (RLS) ----------
alter table public.config enable row level security;
alter table public.config_privada enable row level security;
alter table public.fornecedores enable row level security;
alter table public.produtos enable row level security;
alter table public.produtos_privado enable row level security;
alter table public.banners enable row level security;
alter table public.eventos enable row level security;

create policy config_ler on public.config for select to anon, authenticated using (true);
create policy config_adm on public.config for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy produtos_ler on public.produtos for select to anon, authenticated using (ativo or public.is_admin());
create policy produtos_adm on public.produtos for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy banners_ler on public.banners for select to anon, authenticated using (ativo or public.is_admin());
create policy banners_adm on public.banners for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy priv_adm on public.produtos_privado for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy forn_adm on public.fornecedores for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy cfgpriv_adm on public.config_privada for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy ev_inserir on public.eventos for insert to anon, authenticated with check (true);
create policy ev_ler on public.eventos for select to authenticated using (public.is_admin());

revoke all on public.admins, public.setup_admin, public.config_privada, public.fornecedores, public.produtos_privado from anon;
revoke all on public.eventos from anon, authenticated;
grant insert on public.eventos to anon, authenticated;
grant select on public.eventos to authenticated;
grant usage, select on sequence public.eventos_id_seq to anon, authenticated;
grant select on public.config, public.produtos, public.banners to anon, authenticated;
grant insert, update, delete on public.config, public.produtos, public.banners, public.fornecedores, public.produtos_privado, public.config_privada to authenticated;
grant select on public.fornecedores, public.produtos_privado, public.config_privada to authenticated;
revoke all on function public.is_admin() from public; grant execute on function public.is_admin() to anon, authenticated;
revoke all on function public.claim_admin(text) from public; grant execute on function public.claim_admin(text) to authenticated;

-- ---------- estatísticas (só admin) ----------
create or replace function public.stats_resumo(dias int default 7) returns jsonb
language plpgsql stable security definer set search_path=public as $$
declare r jsonb; hoje date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select jsonb_build_object(
    'visitantes',(select count(distinct visitante) from eventos where tipo='visita'),
    'visitas',(select count(*) from eventos where tipo='visita'),
    'zap',(select count(*) from eventos where tipo='zap'),
    'interesse',(select count(*) from eventos where tipo='interesse'),
    'pedidos',(select count(*) from eventos where tipo='pedido'),
    'orcamentos',(select count(*) from eventos where tipo='pedido' and objetivo='orcamento'),
    'compras',(select count(*) from eventos where tipo='pedido' and objetivo='compra'),
    'revenda',(select count(*) from eventos where tipo='revenda'),
    'dias',(select coalesce(jsonb_agg(jsonb_build_object('dia',to_char(d,'YYYY-MM-DD'),
        'visitas',(select count(*) from eventos e where e.tipo='visita' and (e.created_at at time zone 'America/Sao_Paulo')::date=d),
        'zap',(select count(*) from eventos e where e.tipo='zap' and (e.created_at at time zone 'America/Sao_Paulo')::date=d)) order by d desc),'[]'::jsonb)
        from generate_series(hoje-(dias-1),hoje,interval '1 day') g(d0), lateral (select g.d0::date as d) x),
    'produtos',(select coalesce(jsonb_agg(jsonb_build_object('produto',produto,'n',n) order by n desc),'[]'::jsonb)
        from (select produto,count(*) n from eventos where tipo='interesse' and produto is not null group by produto order by n desc limit 10) q)
  ) into r;
  return r;
end $$;
revoke all on function public.stats_resumo(int) from public; grant execute on function public.stats_resumo(int) to authenticated;

-- ---------- aba de REVENDA (lista com preço de revenda, protegida por código) ----------
create or replace function public.revenda_lista(codigo text) returns jsonb
language plpgsql stable security definer set search_path=public as $$
declare h text := encode(digest(coalesce(codigo,''),'sha256'),'hex'); m numeric;
begin
  if not exists(select 1 from config_privada where codigo_revenda_hash=h) then raise exception 'codigo invalido'; end if;
  select margem_revenda into m from config where id=1;
  return coalesce((select jsonb_agg(jsonb_build_object('id',p.id,'nome',p.nome,'detalhes',p.detalhes,'condicao',p.condicao,
      'img',p.img,'bateria',p.bateria,'grade',p.grade,'armazenamento',p.armazenamento,'cores',p.cores,
      'preco_revenda',coalesce(v.preco_revenda, case when v.custo>0 then ceil(v.custo*(1+coalesce(m,8)/100)/10)*10 end)) order by p.ordem)
    from produtos p left join produtos_privado v on v.produto_id=p.id where p.ativo),'[]'::jsonb);
end $$;
revoke all on function public.revenda_lista(text) from public; grant execute on function public.revenda_lista(text) to anon, authenticated;

-- ---------- fotos (Storage) ----------
insert into storage.buckets (id,name,public) values ('fotos','fotos',true) on conflict (id) do nothing;
create policy fotos_adm on storage.objects for all to authenticated
  using (bucket_id='fotos' and public.is_admin()) with check (bucket_id='fotos' and public.is_admin());
