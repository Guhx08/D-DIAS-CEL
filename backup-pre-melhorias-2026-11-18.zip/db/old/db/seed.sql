-- ===== dados iniciais =====
insert into public.config(id,nome,cidade,wa,ig,logo) values (1,'D’DIAS CEL','Osasco - SP','5511964013198','d.diascel','https://daqjvsyrnfzyttyrzlvq.supabase.co/storage/v1/object/public/istore-images-new/ac263e38-0382-4f72-baa7-ce3be636e6e1/logos/16ba01801b962e009f5ba27e4058f8bc08792455958d4c3ca1ccd06c375307ea.jpeg') on conflict (id) do nothing;
insert into public.setup_admin(id,code_hash) values (1,encode(digest('DD-W8E1CHYS','sha256'),'hex')) on conflict (id) do nothing;
insert into public.config_privada(id,codigo_revenda_hash) values (1,encode(digest('REV-Z8FBC5','sha256'),'hex')) on conflict (id) do nothing;
insert into public.produtos(nome,detalhes,condicao,preco,promo,img,cores,ativo,ordem) values
('iPhone 18 Pro Max','256GB · 4 cores','Lacrado',9050,0,'imagens/iphone-18-pro-max.jpg','["#b8aea4|Bege", "#4a90e2|Azul", "#1c1c1e|Preto", "#7a2a35|Vinho"]'::jsonb,true,1),
('iPhone 17 Pro Max','256GB · 1 cor','Semi',7590,0,'imagens/iphone-17-pro-max.jpg','["#b8aea4|Bege"]'::jsonb,true,2),
('iPhone 17 Pro','256GB · 1 cor','Semi',6500,0,'imagens/iphone-17-pro.jpg','["#e0752f|Laranja"]'::jsonb,true,3),
('iPhone 17','256GB · 1 cor','Semi',5000,0,'imagens/iphone-17.jpg','["#a8c5ae|Verde"]'::jsonb,true,4),
('iPhone 16 Pro Max','256GB · 2 cores','Semi',5150,0,'imagens/iphone-16-pro-max.jpg','["#b8aea4|Bege", "#eeeeee|Branco"]'::jsonb,true,5),
('iPhone 16 Pro','2 cores','Semi',4400,0,'imagens/iphone-16-pro.jpg','["#e6cf9f|Dourado", "#b8aea4|Bege"]'::jsonb,true,6),
('iPhone 15 Pro Max','256GB · 3 cores','Semi',4280,0,'imagens/iphone-15-pro-max.jpg','["#eeeeee|Branco", "#4a90e2|Azul", "#b8aea4|Bege"]'::jsonb,true,7),
('iPhone 15 Pro','1 cor','Semi',3650,0,'imagens/iphone-15-pro.jpg','["#4a90e2|Azul"]'::jsonb,true,8),
('iPhone 15 Plus','1 cor','Semi',3050,0,'imagens/iphone-15-plus.jpg','["#4a90e2|Azul"]'::jsonb,true,9),
('iPhone 15','1 cor','Semi',2950,0,'imagens/iphone-15.jpg','["#1c1c1e|Preto"]'::jsonb,true,10),
('iPhone 14 Pro Max','2 cores','Semi',3450,0,'imagens/iphone-14-pro-max.jpg','["#1c1c1e|Preto", "#eeeeee|Branco"]'::jsonb,true,11),
('iPhone 14 Pro','256GB · 1 cor','Semi',3150,0,'imagens/iphone-14-pro.jpg','["#e6cf9f|Dourado"]'::jsonb,true,12),
('iPhone 14','1 cor','Semi',2230,0,'imagens/iphone-14.jpg','["#8a8a8a|Cinza"]'::jsonb,true,13),
('iPhone 13','2 cores','Semi · Grade A+',1800,0,'imagens/iphone-13.jpg','["#1c1c1e|Preto", "#4a90e2|Azul"]'::jsonb,true,14),
('iPhone 12','1 cor','Semi · Grade A+',1790,0,'imagens/iphone-12.jpg','["#1c1c1e|Preto"]'::jsonb,true,15),
('iPhone Duo','512GB · 2 cores','Lacrado',15500,0,'imagens/iphone-duo.jpg','["#f0f0f0|Branco", "#1c1c1e|Preto"]'::jsonb,true,16),
('Carregador USB-C – 20W','1 cor','Lacrado',185.99,0,'imagens/carregador-usb-c-20w.jpg','["#cccccc|Branco"]'::jsonb,true,17);
insert into public.banners(ativo,titulo,subtitulo,botao,mensagem,cor,img,ordem) values
(true,'iPhone 18 Pro Max chegou!','Lacrado, com garantia e entrega rápida. A partir de R$ 9.050,00.','Quero o meu','Olá! Tenho interesse no iPhone 18 Pro Max lacrado.','#FF6B00,#ff9a3c','',1),
(true,'Seminovos revisados com garantia','Procedência, teste completo e parcelamento no cartão.','Ver seminovos','','#16181d,#3a3f4a','',2),
(true,'Entrega rápida em Osasco e região','Chame no WhatsApp e receba no mesmo dia.','Falar agora','Olá! Gostaria de saber sobre entrega.','#0f766e,#14b8a6','',3);
