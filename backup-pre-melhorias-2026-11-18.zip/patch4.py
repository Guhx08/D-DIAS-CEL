s=open('site/index.html',encoding='utf-8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:60];s=s.replace(a,b)
rep("button{font-family:inherit}\n",""".dt{background:#f7f7f5;border-radius:14px;padding:4px 14px;margin:10px 0}
.dr{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid var(--line);font-size:13px}
.dr:last-child{border:0}.dr span{color:var(--mut)}.dr b{text-align:right}
.bt{height:8px;border-radius:6px;background:#e5e5e0;overflow:hidden;margin:-2px 0 10px}.bt b{display:block;height:100%}
button{font-family:inherit}
""")
rep("d.className='card';","d.className='card';d.dataset.o=D.produtos.indexOf(p);d.style.cursor='pointer';")
a=s.index("function order(p){");b=s.index("$('grid').addEventListener('click'")
new=r'''function order(p){
  hit('interesse');hit('i-'+slug(p.n));
  var v=pr(p),pm=v<p.p,cs=(p.cores||[]).map(cor),m=$('md'),O={cor:cs.length===1?cs[0].n:'',ob:'',pg:'Pix',en:'Receber em casa'},nm='';
  try{nm=localStorage.getItem('dd_nome')||''}catch(e){}
  var g=(k,a)=>'<div class="opts" data-g="'+k+'">'+a.map(x=>'<button type="button" class="op'+(O[k]===x.n?' on':'')+'" data-v="'+x.n+'">'+(x.h?'<i style="background:'+x.h+'"></i>':'')+x.n+'</button>').join('')+'</div>';
  var row=(k,x)=>x?'<div class="dr"><span>'+k+'</span><b>'+x+'</b></div>':'',semi=p.c.indexOf('Semi')===0;
  var det=row('Condição',p.c)+row('Detalhes',p.e)+row('Armazenamento',p.arm)
   +(p.bat?'<div class="dr"><span>Saúde da bateria</span><b>'+p.bat+'%</b></div><div class="bt"><b style="width:'+p.bat+'%;background:'+(p.bat>=90?'#16a34a':p.bat>=80?'#f59e0b':'#ef4444')+'"></b></div>':(semi?row('Saúde da bateria','informamos no atendimento'):''))
   +row('Estado / grade',p.gr)+row('Acompanha',p.ac)+row('Garantia',p.gar)+row('Observações',p.ob);
  m.innerHTML='<div class="md"><button class="x" data-x aria-label="Fechar">×</button><div class="mh"><img src="'+(p.img||PH)+'" alt=""><div><h3>'+p.n+'</h3><strong>'+brl(v)+'</strong>'+(pm?' <s>'+brl(p.p)+'</s>':'')+'</div></div><div class="dt">'+det+'</div>'
   +(cs.length?'<label>Cor</label>'+g('cor',cs):'')
   +'<label>O que você deseja?</label>'+g('ob',[{n:'Só um orçamento'},{n:'Quero comprar'}])
   +'<div id="cp" hidden><label>Pagamento</label>'+g('pg',[{n:'Pix'},{n:'Cartão'}])+'<label>Entrega</label>'+g('en',[{n:'Receber em casa'},{n:'Retirar na loja'}])
   +'<div id="bf"><label>Bairro / endereço (opcional)</label><input id="bai" placeholder="Ex.: Centro, Osasco"></div></div>'
   +'<label>Seu nome</label><input id="nom" value="'+nm.replace(/"/g,'&quot;')+'" placeholder="Como podemos te chamar?">'
   +'<label>Observação (opcional)</label><input id="obs" placeholder="Ex.: tenho um aparelho para dar na troca">'
   +'<p id="er" style="color:#b91c1c;font-size:13px;margin-top:10px"></p><button class="btn" id="go" style="width:100%;justify-content:center;margin-top:8px">Enviar pelo WhatsApp</button></div>';
  m.onclick=e=>{var t=e.target;
    if(t===m||t.hasAttribute('data-x'))return m.close();
    var b=t.closest('.op');
    if(b){var gr=b.parentNode.dataset.g;O[gr]=b.dataset.v;b.parentNode.querySelectorAll('.op').forEach(x=>x.classList.toggle('on',x===b));
      if(gr==='ob')$('cp').hidden=O.ob!=='Quero comprar';
      if(gr==='en')$('bf').hidden=O.en!=='Receber em casa'}
    if(t.id==='go'){var n=$('nom').value.trim();
      if(cs.length>1&&!O.cor)return $('er').textContent='Escolha a cor do aparelho.';
      if(!O.ob)return $('er').textContent='Escolha: só um orçamento ou quero comprar.';
      if(!n)return $('er').textContent='Informe seu nome.';
      try{localStorage.setItem('dd_nome',n)}catch(x){}
      var buy=O.ob==='Quero comprar',bai=$('bai').value.trim(),ob=$('obs').value.trim();
      var L=[buy?'🛒 *NOVO PEDIDO — '+D.config.nome+'*':'💬 *PEDIDO DE ORÇAMENTO — '+D.config.nome+'*','','🎯 *Objetivo:* '+(buy?'Comprar o aparelho':'Apenas orçamento'),'📱 *Produto:* '+p.n,'🔹 *Condição:* '+p.c,p.e?'💾 *Detalhes:* '+p.e:null,p.bat?'🔋 *Bateria:* '+p.bat+'%':null,O.cor?'🎨 *Cor:* '+O.cor:null,'💰 *Valor:* '+brl(v)+(pm?' (promoção, de '+brl(p.p)+')':''),buy?'💳 *Pagamento:* '+O.pg:null,buy?'🚚 *Entrega:* '+O.en+(O.en==='Receber em casa'&&bai?' — '+bai:''):null,'👤 *Nome:* '+n,ob?'📝 *Obs.:* '+ob:null,'',buy?'Aguardo a confirmação de disponibilidade. 🙌':'Pode me passar um orçamento, por favor? 🙌'];
      zap();hit('pedidos');hit(buy?'compras':'orcamentos');window.open(wa(L.filter(x=>x!==null).join('\n')),'_blank');m.close()}};
  m.showModal();
}
'''
s=s[:a]+new+s[b:]
open('site/index.html','w',encoding='utf-8').write(s)
