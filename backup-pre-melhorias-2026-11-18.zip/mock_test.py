import json,re,uuid,urllib.parse
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse,parse_qs
D=json.load(open('site/dados.json',encoding='utf-8'))
for f in ['index','admin']:
    s=open(f'/mnt/user-data/outputs/preview-{f}.html',encoding='utf-8').read().replace('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRubWdnc3Jpb2tkbWtzenRnb2NoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ4NzAzNzYsImV4cCI6MjExMDQ0NjM3Nn0.C5cEHQfOSEN_Cg76-7oX1VvTgmnH9objgYwqWnumJt0','FAKEKEY')
    open(f'/tmp/t-{f}.html','w',encoding='utf-8').write(s)
T={'produtos':[],'banners':[],'config':[{'id':1,'nome':D['config']['nome'],'cidade':D['config']['cidade'],'wa':D['config']['wa'],'ig':D['config']['ig'],'logo':'','margem_revenda':8}],'fornecedores':[],'produtos_privado':[],'eventos':[],'config_privada':[]}
for i,p in enumerate(D['produtos'],1):
    T['produtos'].append(dict(id=str(uuid.uuid4()),nome=p['n'],detalhes=p['e'],condicao=p['c'],preco=p['p'],promo=0,img='',cores=p['cores'],ativo=True,ordem=i,armazenamento=None,bateria=None,grade=None,garantia=None,acompanha=None,obs=None))
T['produtos'][6]['bateria']=92;T['produtos'][6]['grade']='A+'
for i,b in enumerate(D['banners'],1):T['banners'].append(dict(id=str(uuid.uuid4()),ativo=True,titulo=b['t'],subtitulo=b['s'],botao=b['b'],mensagem=b['q'],cor=b['bg'],img='',ordem=i))
CORS={'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'}
LOG=[]
def match(row,q):
    for k,v in q.items():
        if k in('select','order','on_conflict'):continue
        v=v[0]
        if v.startswith('eq.'):
            x=row.get(k);x='true' if x is True else 'false' if x is False else str(x)
            if x!=v[3:]:return False
        elif v.startswith('gt.'):
            if not (row.get(k) or 0)>float(v[3:]):return False
    return True
def h(route):
    r=route.request;u=urlparse(r.url);q=parse_qs(u.query);p=u.path;m=r.method
    if m=='OPTIONS':return route.fulfill(status=204,headers=CORS)
    def js(o,st=200):route.fulfill(status=st,content_type='application/json',headers=CORS,body=json.dumps(o))
    body=json.loads(r.post_data) if r.post_data and 'json' in (r.headers.get('content-type') or '') else None
    LOG.append((m,p+('?'+u.query if u.query else ''),body))
    if p.startswith('/auth/v1/token'):return js({'access_token':'TOK','refresh_token':'RT','expires_in':3600})
    if p.startswith('/auth/v1/signup'):return js({})
    if p.startswith('/storage/'):return js({'Key':'ok'})
    if p.startswith('/rest/v1/rpc/'):
        f=p.split('/')[-1]
        if f=='is_admin':return js('TOK' in r.headers.get('authorization',''))
        if f=='claim_admin':return js(True)
        if f=='stats_resumo':return js({'visitantes':4,'visitas':56,'zap':32,'interesse':9,'pedidos':3,'orcamentos':1,'compras':2,'revenda':2,'dias':[{'dia':'2026-11-16','visitas':10,'zap':6},{'dia':'2026-11-15','visitas':4,'zap':1}],'produtos':[{'produto':'iPhone 15','n':5}]})
        if f=='revenda_lista':
            if body.get('codigo')!='REV-TEST':return js({'message':'codigo invalido'},400)
            out=[]
            for x in T['produtos']:
                v=next((a for a in T['produtos_privado'] if a['produto_id']==x['id']),{})
                out.append(dict(id=x['id'],nome=x['nome'],detalhes=x['detalhes'],condicao=x['condicao'],img=x['img'],bateria=x['bateria'],preco_revenda=v.get('custo') and v['custo']*1.08))
            return js(out)
    t=p.split('/rest/v1/')[-1];rows=T[t]
    if m=='GET':
        out=[x for x in rows if match(x,q)]
        if 'order' in q:
            k=q['order'][0].split('.')[0];out.sort(key=lambda x:(x.get(k) is None,x.get(k) or 0 if not isinstance(x.get(k),str) else 0,str(x.get(k))))
        return js(out)
    if m=='POST':
        new=dict(body);
        if t=='produtos_privado':
            ex=next((a for a in rows if a['produto_id']==new['produto_id']),None)
            if ex:ex.update(new)
            else:rows.append(new)
            return route.fulfill(status=201,headers=CORS,body='')
        new.setdefault('id',str(uuid.uuid4()))
        if t=='produtos':new.setdefault('ativo',True);new.setdefault('promo',0);new.setdefault('cores',[]);new.setdefault('detalhes','')
        rows.append(new)
        if 'representation' in (r.headers.get('prefer') or ''):return js([new],201)
        return route.fulfill(status=201,headers=CORS,body='')
    if m=='PATCH':
        for x in rows:
            if match(x,q):x.update(body)
        return route.fulfill(status=204,headers=CORS)
    if m=='DELETE':
        T[t]=[x for x in rows if not match(x,q)];return route.fulfill(status=204,headers=CORS)
    route.fulfill(status=404,headers=CORS,body='{}')
ok=lambda c,msg:print(('PASS ' if c else 'FAIL ')+msg)
with sync_playwright() as pw:
    b=pw.chromium.launch()
    # ========== SITE (visitante) ==========
    c=b.new_context(viewport={'width':430,'height':900});c.route('**/tnmggsriokdmksztgoch.supabase.co/**',h);pg=c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///tmp/t-index.html');pg.wait_for_timeout(1500)
    ok(pg.locator('#grid .card').count()==8,'site le produtos do Supabase (8 por pagina)')
    ok(any(l[0]=='POST' and 'eventos' in l[1] and l[2]['tipo']=='visita' for l in LOG),'registra evento "visita" no banco')
    pg.fill('#q','15 pro max');pg.wait_for_timeout(200);pg.click('#grid .card .ph');pg.wait_for_timeout(300)
    ok('92%' in pg.inner_text('#md'),'detalhes vindos do banco (bateria 92%)')
    pg.click('.opts[data-g="cor"] .op >> nth=0');pg.click('.op[data-v="Quero comprar"]');pg.fill('#nom','Ana')
    pg.evaluate("window.open=u=>{window.__u=u}");pg.click('#go')
    ok(any(l[0]=='POST' and 'eventos' in l[1] and l[2]['tipo']=='pedido' and l[2]['objetivo']=='compra' for l in LOG),'registra pedido (compra) no banco')
    pg.click('#tbs .chip[data-t=r]');pg.wait_for_timeout(300)
    pg.fill('#rc','ERRADO');pg.click('#rb');pg.wait_for_timeout(500);ok('inválido' in pg.inner_text('#re'),'revenda: codigo errado e recusado')
    T['produtos_privado'].append({'produto_id':T['produtos'][0]['id'],'custo':5000})
    pg.fill('#rc','REV-TEST');pg.click('#rb');pg.wait_for_timeout(600)
    ok(pg.locator('.rr').count()==17,'revenda: codigo certo mostra 17 aparelhos')
    pg.fill('.qt >> nth=0','2');pg.wait_for_timeout(200);print('   total:',pg.inner_text('#rt'))
    pg.fill('#rn','Loja Teste');pg.click('#rs');u=urllib.parse.unquote(pg.evaluate('window.__u').split('text=')[1]);print('   msg revenda:\n   '+u.replace('\n','\n   '))
    ok(not errs,'site sem erros JS '+str(errs));c.close()
    # ========== PAINEL ==========
    c=b.new_context(viewport={'width':430,'height':900});c.route('**/tnmggsriokdmksztgoch.supabase.co/**',h);c.route('**/cdn.jsdelivr.net/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=open('qr/package/qrcode.js').read()))
    ad=c.new_page();errs=[];ad.on('pageerror',lambda e:errs.append(str(e)));ad.on('dialog',lambda d:d.dismiss())
    ad.goto('file:///tmp/t-admin.html');ad.wait_for_timeout(800)
    ad.fill('#em','dono@loja.com');ad.fill('#pw','senha123');ad.click('#ok');ad.wait_for_timeout(1500)
    ok(ad.is_visible('#v-home'),'painel: login com e-mail/senha e abre a tela inicial')
    ok(ad.inner_text('#tv')=='56' and ad.inner_text('#tz')=='32','painel: visitas/cliques vindos do banco')
    ad.click('.qk[data-go=produtos] >> nth=0');ad.wait_for_timeout(300)
    ad.fill('.it >> nth=0 >> [data-k=preco]','9100');ad.wait_for_timeout(1500)
    ok(T['produtos'][0]['preco']==9100,'painel: editar preco grava no banco (PATCH)')
    ad.fill('#dp','10');ad.click('#ap');ad.wait_for_timeout(800);ok(all(p['promo']>0 for p in T['produtos']),'painel: promocao em lote grava no banco')
    ad.click('#v-produtos .bk');ad.click('.qk[data-go=add]');ad.wait_for_timeout(300)
    txt="iPhone 13 128GB azul bateria 89% 2.100\n*iPhone 15 Pro Max* 256GB titânio natural LACRADO R$ 7.350,00\n📱 14 Pro 256 preto bat 91% grade A+ 3.150\nlinha qualquer sem aparelho"
    ad.fill('#wt',txt);ad.click('#wp');ad.wait_for_timeout(300)
    print('   lidos:',ad.locator('#wr tr[data-i]').count(),'->',[ad.eval_on_selector_all('#wr tr[data-i]','trs=>trs.map(t=>[...t.querySelectorAll("input,select")].filter(e=>e.dataset.r!=="on").map(e=>e.value).join(" | "))')][0])
    n0=len(T['produtos']);ad.click('#wpub');ad.wait_for_timeout(1500)
    ok(len(T['produtos'])==n0+3,'WhatsApp: 3 anuncios criados no banco');novo=[p for p in T['produtos'] if p['nome']=='iPhone 13'][0]
    print('   criado:',{k:novo[k] for k in('nome','detalhes','condicao','preco','armazenamento','bateria','cores')})
    print('   anuncio:\n   '+ad.inner_text('#wr .ad >> nth=0').replace('\n','\n   '))
    # custo do fornecedor
    ad.click('.qk[data-go=add]') if False else None
    ad.goto('file:///tmp/t-admin.html');ad.wait_for_timeout(600);ad.click('.qk[data-go=add]');ad.fill('#wt','iPhone 12 64GB preto bat 85% 1.400');ad.select_option('#wm','custo');ad.fill('#wg','20');ad.click('#wp');ad.wait_for_timeout(300)
    print('   preco c/ margem 20% sobre custo 1400 =',ad.input_value('#wr tr[data-i] [data-r=venda]'))
    ad.click('#wpub');ad.wait_for_timeout(1200);ok(any(a.get('custo')==1400 for a in T['produtos_privado']),'custo do fornecedor gravado em tabela privada')
    ad.click('#v-add .bk');ad.click('.qk[data-go=revenda]');ad.fill('#rm2','10');ad.fill('#rc2','NOVO-COD');ad.click('#rsv');ad.wait_for_timeout(600);ok(T['config'][0]['margem_revenda']==10,'revenda: margem salva')
    ad.click('#v-revenda .bk');ad.click('.tile[data-go=stats]');ad.wait_for_timeout(500);ok('56' in ad.inner_text('#sx'),'estatisticas vindas do banco')
    ok(not errs,'painel sem erros JS '+str(errs));b.close()
